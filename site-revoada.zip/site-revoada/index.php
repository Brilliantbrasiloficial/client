<?php
// Configurações do site
$site_nome    = "Revoada RJ";
$site_tagline = "O jogo de azar mais emocionante do Brasil";
$apk_link     = "#download"; // Substitua pelo link real do APK
$apk_versao   = "2.4.1";
$apk_tamanho  = "45 MB";
$apk_android  = "Android 5.0+";
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= htmlspecialchars($site_nome) ?> - <?= htmlspecialchars($site_tagline) ?>. Baixe o APK agora e comece a ganhar!">
    <meta name="keywords" content="revoada, jogo, apk, apostas, cassino, ganhar dinheiro">
    <meta property="og:title" content="<?= htmlspecialchars($site_nome) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($site_tagline) ?>">
    <meta property="og:image" content="assets/img/logo-revoada.png">
    <meta name="theme-color" content="#00a8ff">
    <title><?= htmlspecialchars($site_nome) ?> | <?= htmlspecialchars($site_tagline) ?></title>
    <link rel="icon" href="assets/img/logo-revoada.png" type="image/png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<!-- TICKER -->
<div class="ticker-bar">
    <div class="ticker-content" id="tickerContent">
        <span class="ticker-item"><span class="ticker-dot"></span> Novo APK disponível - Versão <?= $apk_versao ?></span>
        <span class="ticker-item"><span class="ticker-dot"></span> Mais de 500 mil jogadores ativos</span>
        <span class="ticker-item"><span class="ticker-dot"></span> Saque rápido em até 5 minutos</span>
        <span class="ticker-item"><span class="ticker-dot"></span> Suporte 24 horas por dia</span>
        <span class="ticker-item"><span class="ticker-dot"></span> Jogo 100% seguro e verificado</span>
        <span class="ticker-item"><span class="ticker-dot"></span> Bônus de boas-vindas para novos usuários</span>
    </div>
</div>

<!-- NAVBAR -->
<nav class="navbar">
    <a href="#" class="navbar-brand">
        <img src="assets/img/logo-revoada.png" alt="<?= htmlspecialchars($site_nome) ?>">
    </a>
    <div class="hamburger" id="hamburger">
        <span></span><span></span><span></span>
    </div>
    <ul class="navbar-menu" id="navMenu">
        <li><a href="#inicio">Início</a></li>
        <li><a href="#sobre">Sobre</a></li>
        <li><a href="#como-jogar">Como Jogar</a></li>
        <li><a href="#download">APK</a></li>
        <li><a href="#contato">Contato</a></li>
        <li><a href="#download" class="btn-nav-download">⬇ Baixar APK</a></li>
    </ul>
</nav>

<!-- HERO -->
<section class="hero" id="inicio">
    <div class="hero-particles"></div>
    <div class="hero-bg"></div>
    <div class="hero-content">
        <img src="assets/img/logo-revoada.png" alt="<?= htmlspecialchars($site_nome) ?>" class="hero-logo">
        <div class="hero-badge">🏆 Jogo Original com APK Próprio</div>
        <h1>Bem-vindo ao<br><?= htmlspecialchars($site_nome) ?></h1>
        <p>O jogo de entretenimento mais emocionante do Brasil. Centenas de milhares de jogadores já fazem parte dessa comunidade. Baixe o APK agora e entre nessa!</p>
        <div class="hero-buttons">
            <a href="#download" class="btn-primary">
                <span>📱</span> Baixar APK Grátis
            </a>
            <a href="#como-jogar" class="btn-secondary">
                <span>▶</span> Como Funciona
            </a>
        </div>
    </div>
</section>

<!-- STATS -->
<div class="stats">
    <div class="stats-grid">
        <div class="stat-item">
            <span class="stat-number" data-count="500000" data-suffix="+">0</span>
            <span class="stat-label">Jogadores Ativos</span>
        </div>
        <div class="stat-item">
            <span class="stat-number" data-count="98" data-suffix="%">0%</span>
            <span class="stat-label">Taxa de Aprovação</span>
        </div>
        <div class="stat-item">
            <span class="stat-number" data-count="5" data-suffix="min">0min</span>
            <span class="stat-label">Tempo de Saque</span>
        </div>
        <div class="stat-item">
            <span class="stat-number" data-count="24" data-suffix="h">0h</span>
            <span class="stat-label">Suporte Online</span>
        </div>
    </div>
</div>

<!-- SOBRE / FEATURES -->
<section class="section" id="sobre">
    <div class="section-header">
        <div class="section-tag">✦ Por que nos escolher</div>
        <h2 class="section-title">Por que jogar no <span><?= htmlspecialchars($site_nome) ?></span>?</h2>
        <div class="section-line"></div>
    </div>
    <div class="features-grid">
        <div class="feature-card">
            <div class="feature-icon">🔒</div>
            <h3>100% Seguro</h3>
            <p>Plataforma protegida com tecnologia de criptografia avançada. Seus dados e seus ganhos estão sempre protegidos.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon">💰</div>
            <h3>Saques Rápidos</h3>
            <p>Retire seus ganhos em menos de 5 minutos via PIX. Sem burocracia, sem demora, direto na sua conta.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon">📱</div>
            <h3>APK Exclusivo</h3>
            <p>Aplicativo próprio desenvolvido especialmente para o Revoada RJ. Experiência otimizada e leve no seu celular.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon">🎁</div>
            <h3>Bônus Generosos</h3>
            <p>Bônus de boas-vindas, rodadas grátis e promoções especiais para nossos jogadores. Aproveite ao máximo!</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon">🏆</div>
            <h3>Tornamentos</h3>
            <p>Participe de competições e torneios exclusivos com premiações incríveis para os melhores jogadores.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon">🎧</div>
            <h3>Suporte 24/7</h3>
            <p>Nossa equipe de suporte está disponível a qualquer hora do dia para ajudar com qualquer dúvida ou problema.</p>
        </div>
    </div>
</section>

<!-- DOWNLOAD APK -->
<section class="section download-section" id="download">
    <div class="section-header">
        <div class="section-tag">✦ Aplicativo Oficial</div>
        <h2 class="section-title">Baixe o <span>APK Oficial</span></h2>
        <div class="section-line"></div>
    </div>
    <div class="download-card">
        <div class="download-icon-wrap">📱</div>
        <h2><?= htmlspecialchars($site_nome) ?> APK</h2>
        <p>Nosso aplicativo exclusivo desenvolvido para a melhor experiência de jogo. Rápido, seguro e fácil de usar.</p>
        <div class="download-info">
            <span class="download-badge"><span>📌</span> Versão <?= htmlspecialchars($apk_versao) ?></span>
            <span class="download-badge"><span>💾</span> <?= htmlspecialchars($apk_tamanho) ?></span>
            <span class="download-badge"><span>🤖</span> <?= htmlspecialchars($apk_android) ?></span>
            <span class="download-badge"><span>✅</span> Gratuito</span>
        </div>
        <a href="<?= htmlspecialchars($apk_link) ?>" class="btn-download-apk">
            <span>⬇</span> BAIXAR APK AGORA
        </a>
        <div class="aviso-banner" style="margin-top: 30px;">
            <span class="aviso-icon">⚠️</span>
            <span>Para instalar o APK, ative a opção <strong>"Instalar apps de fontes desconhecidas"</strong> nas configurações do seu Android. Baixe apenas pelo link oficial.</span>
        </div>
    </div>
</section>

<!-- COMO JOGAR -->
<section class="section" id="como-jogar">
    <div class="section-header">
        <div class="section-tag">✦ Guia Rápido</div>
        <h2 class="section-title">Como <span>Começar</span> a Jogar</h2>
        <div class="section-line"></div>
    </div>
    <div class="steps-grid">
        <div class="step-card">
            <div class="step-number">1</div>
            <div class="step-icon">⬇️</div>
            <h3>Baixe o APK</h3>
            <p>Clique no botão de download acima e baixe nosso aplicativo oficial diretamente no seu Android.</p>
        </div>
        <div class="step-card">
            <div class="step-number">2</div>
            <div class="step-icon">📲</div>
            <h3>Instale o App</h3>
            <p>Abra o arquivo APK no seu celular e siga os passos para instalar. É rápido e fácil!</p>
        </div>
        <div class="step-card">
            <div class="step-number">3</div>
            <div class="step-icon">📝</div>
            <h3>Crie sua Conta</h3>
            <p>Cadastre-se gratuitamente com seu CPF e número de celular. Processo simples e rápido.</p>
        </div>
        <div class="step-card">
            <div class="step-number">4</div>
            <div class="step-icon">💵</div>
            <h3>Faça um Depósito</h3>
            <p>Deposite a partir de R$ 10 via PIX e ganhe seu bônus de boas-vindas exclusivo.</p>
        </div>
        <div class="step-card">
            <div class="step-number">5</div>
            <div class="step-icon">🎮</div>
            <h3>Comece a Jogar</h3>
            <p>Explore os jogos disponíveis, aposte e divirta-se! Os saques são liberados rapidamente.</p>
        </div>
    </div>
</section>

<!-- GALERIA DE CAPTURAS -->
<section class="section gallery-section">
    <div class="section-header">
        <div class="section-tag">✦ Screenshots</div>
        <h2 class="section-title">Veja o <span>Aplicativo</span> em Ação</h2>
        <div class="section-line"></div>
    </div>
    <div class="gallery-grid">
        <div class="gallery-item">🎰<span class="gallery-label">Lobby Principal</span></div>
        <div class="gallery-item">🏆<span class="gallery-label">Torneios ao Vivo</span></div>
        <div class="gallery-item">💰<span class="gallery-label">Área de Saques</span></div>
        <div class="gallery-item">🎁<span class="gallery-label">Promoções</span></div>
        <div class="gallery-item">📊<span class="gallery-label">Histórico de Jogadas</span></div>
        <div class="gallery-item">👤<span class="gallery-label">Meu Perfil</span></div>
    </div>
</section>

<!-- DEPOIMENTOS -->
<section class="section" style="background: rgba(0,5,15,0.7);">
    <div class="section-header">
        <div class="section-tag">✦ Jogadores</div>
        <h2 class="section-title">O que nossos <span>Jogadores</span> dizem</h2>
        <div class="section-line"></div>
    </div>
    <div class="testimonials-grid">
        <?php
        $depoimentos = [
            ["nome" => "Marcos Silva",  "loc" => "Rio de Janeiro, RJ", "texto" => "Melhor plataforma que já joguei! Saquei R$ 850 em menos de 3 minutos via PIX. Recomendo demais pra galera!"],
            ["nome" => "Ana Paula",     "loc" => "São Paulo, SP",       "texto" => "O aplicativo é muito leve e não trava no meu celular. Os jogos são viciantes e o bônus de entrada foi incrível!"],
            ["nome" => "Ricardo Costa", "loc" => "Belo Horizonte, MG",  "texto" => "Já tentei várias plataformas, mas a Revoada RJ é a única que realmente paga rápido. Suporte nota 10!"],
            ["nome" => "Fernanda L.",   "loc" => "Fortaleza, CE",       "texto" => "Nunca pensei que ia ganhar tanto. Comecei com R$ 30 e já saquei R$ 400 na primeira semana. Incrível!"],
            ["nome" => "João Pedro",    "loc" => "Salvador, BA",        "texto" => "APK exclusivo faz toda a diferença. Jogo mais rápido, sem travar e com gráficos lindos. TOP demais!"],
            ["nome" => "Carla Menezes", "loc" => "Curitiba, PR",        "texto" => "Suporte 24h me ajudou a resolver um problema à meia-noite. Atendimento humano de verdade. Perfeito!"],
        ];
        foreach ($depoimentos as $d): ?>
        <div class="testimonial-card">
            <div class="testimonial-stars">★★★★★</div>
            <p class="testimonial-text">"<?= htmlspecialchars($d['texto']) ?>"</p>
            <div class="testimonial-author">
                <div class="author-avatar"><?= mb_substr($d['nome'], 0, 1) ?></div>
                <div>
                    <div class="author-name"><?= htmlspecialchars($d['nome']) ?></div>
                    <div class="author-location">📍 <?= htmlspecialchars($d['loc']) ?></div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- CTA FINAL -->
<section class="cta-section" id="contato">
    <h2>Pronto para Decolar com a<br><span style="color: var(--azul-neon);"><?= htmlspecialchars($site_nome) ?></span>?</h2>
    <p>Junte-se a mais de 500 mil jogadores e comece sua jornada agora mesmo. Baixe o APK gratuitamente!</p>
    <a href="#download" class="btn-primary" style="font-size: 1.05rem; padding: 18px 50px;">
        <span>🚀</span> QUERO JOGAR AGORA
    </a>
</section>

<!-- FOOTER -->
<footer>
    <div class="footer-grid">
        <div class="footer-brand">
            <img src="assets/img/logo-revoada.png" alt="<?= htmlspecialchars($site_nome) ?>">
            <p><?= htmlspecialchars($site_tagline) ?>. A plataforma mais confiável e emocionante do Brasil. Jogue com responsabilidade.</p>
            <div class="social-links" style="margin-top: 20px;">
                <a href="#" class="social-link" title="Telegram">✈</a>
                <a href="#" class="social-link" title="Instagram">📷</a>
                <a href="#" class="social-link" title="WhatsApp">💬</a>
                <a href="#" class="social-link" title="YouTube">▶</a>
            </div>
        </div>
        <div class="footer-col">
            <h4>Navegação</h4>
            <ul>
                <li><a href="#inicio">Início</a></li>
                <li><a href="#sobre">Sobre</a></li>
                <li><a href="#como-jogar">Como Jogar</a></li>
                <li><a href="#download">Baixar APK</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>Suporte</h4>
            <ul>
                <li><a href="#">Central de Ajuda</a></li>
                <li><a href="#">Termos de Uso</a></li>
                <li><a href="#">Privacidade</a></li>
                <li><a href="#">Jogo Responsável</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($site_nome) ?>. Todos os direitos reservados.</p>
        <p style="font-size: 0.8rem; color: rgba(176,196,222,0.4);">Este site é destinado a maiores de 18 anos.</p>
    </div>
</footer>

<script src="assets/js/main.js"></script>
</body>
</html>
