<?php
$site_nome = "Revoada RJ";
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Página não encontrada | <?= htmlspecialchars($site_nome) ?></title>
    <link rel="icon" href="assets/img/logo-revoada.png" type="image/png">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .error-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 20px;
        }
        .error-code {
            font-family: 'Orbitron', sans-serif;
            font-size: clamp(6rem, 20vw, 12rem);
            font-weight: 900;
            background: linear-gradient(135deg, #0066cc, #00a8ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            line-height: 1;
            text-shadow: none;
        }
        .error-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.5rem;
            color: #fff;
            text-transform: uppercase;
            margin: 20px 0 15px;
        }
        .error-text {
            color: #b0c4de;
            font-size: 1rem;
            margin-bottom: 35px;
        }
    </style>
</head>
<body>
<div class="error-page">
    <div>
        <div class="error-code">404</div>
        <div class="error-title">Página não encontrada</div>
        <p class="error-text">Esta página não existe ou foi removida. Volte ao início!</p>
        <a href="index.php" class="btn-primary">
            <span>🏠</span> Voltar ao Início
        </a>
    </div>
</div>
<script src="assets/js/main.js"></script>
</body>
</html>
